// Write a C program to create a child process that runs a different program using exec().
#include <stdio.h>
#include <unistd.h>

int main()
{
    char *args[] = {"ls", "-l", NULL};
    execvp("ls", args);

    perror("execvp");
    return 1;
}